# -*- coding: utf-8 -*-

from . import models
from . import hr_employee
from . import hr_department
from . import documents_folder
from . import documents_document
from . import hr_appraisal
from . import hr_users
from . import hr_contract
from . import project_task
from . import res_partner
