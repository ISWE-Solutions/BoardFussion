# -*- coding: utf-8 -*-

from . import models
from . import video_attachment
from . import project_task
from . import employees
from . import calendar_event_product_line
from . import product_document
from . import knowledge_article
from . import attendees_lines
from . import ir_attachment
from . import calendar_attendee