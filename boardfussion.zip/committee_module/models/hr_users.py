from odoo import api, models, fields, _
from odoo.exceptions import ValidationError

class User(models.Model):
    _inherit = 'res.users'

    member_type = fields.Selection(related='employee_id.member_type', string='Member Type', readonly=False, store=True)

    def toggle_active(self):
        super().toggle_active()  # Call the parent method

        for user in self:
            if not user.active:
                print(f"Archiving user: {user.login} (ID: {user.id})")

                # Archive related partners where the user is tied through employee_ids or partner_id
                partners = self.env['res.partner'].search([
                    '|',  # Use OR to search for both conditions
                    ('employee_ids.user_id', '=', user.id),  # Partners related via employee_ids
                    ('id', '=', user.partner_id.id),  # Partners linked via partner_id
                    ('active', '=', True)  # Only consider active partners for archiving
                ])
                if partners:
                    print(
                        f"Found active partners related to user {user.login}: {[partner.name for partner in partners]}")
                    partners.write({'active': False})  # Deactivate partners
                    print(f"Archived {len(partners)} partner(s) related to user {user.login}")
                else:
                    print(f"No active partners found related to user {user.login}")

            else:
                print(f"Activating user: {user.login} (ID: {user.id})")

                # Unarchive related partners where the user is tied through employee_ids or partner_id
                partners = self.env['res.partner'].search([
                    '|',  # Use OR to search for both conditions
                    ('employee_ids.user_id', '=', user.id),  # Partners related via employee_ids
                    ('id', '=', user.partner_id.id),  # Partners linked via partner_id
                    ('active', '=', False)  # Only consider archived partners for unarchiving
                ])
                if partners:
                    print(
                        f"Found archived partners related to user {user.login}: {[partner.name for partner in partners]}")
                    partners.write({'active': True})  # Reactivate partners
                    print(f"Unarchived {len(partners)} partner(s) related to user {user.login}")
                else:
                    print(f"No archived partners found related to user {user.login} for unarchiving.")

    # def unlink(self):
    #     for user in self:
    #         print(f"Attempting to delete user: {user.login} (ID: {user.id})")
    #
    #         # Check for linked employee records
    #         employees = self.env['hr.employee'].search([('user_id', '=', user.id)])
    #         if employees:
    #             print(f"Found associated employee(s) for user {user.login}: {[emp.name for emp in employees]}")
    #
    #             # Unlink employees before deleting the user
    #             print(f"Unlinking employees associated with user {user.login}")
    #             employees.write({'user_id': False})  # Remove foreign key link to user
    #
    #             # Check if employees are still linked
    #             employees_check = self.env['hr.employee'].search([('user_id', '=', user.id)])
    #             if employees_check:
    #                 print(
    #                     f"ERROR: Employees still linked to user {user.login}: {[emp.name for emp in employees_check]}")
    #                 raise ValidationError(
    #                     f"Cannot delete user {user.login} because employee(s) are still linked: {[emp.name for emp in employees_check]}")
    #             else:
    #                 print(f"All employee links successfully removed for user {user.login}")
    #
    #         # Proceed with user deletion
    #         print(f"Deleting user: {user.login} (ID: {user.id})")
    #         super().unlink()  # Using the simplified super() in Python 3
    #
    #     return True

    # def toggle_active(self):
    #     super().toggle_active()  # Call the parent method
    #
    #     for user in self:
    #         if not user.active:
    #             print(f"Archiving user: {user.login} (ID: {user.id})")
    #
    #             # Archive the associated employee, if active
    #             employee = self.env['hr.employee'].search([('user_id', '=', user.id), ('active', '=', True)])
    #             if employee:
    #                 print(f"Archiving associated employee: {employee.name}")
    #                 employee.write({'active': False})  # Deactivate employee
    #
    #             # Archive related partners where the user is tied through employee_ids or partner_id
    #             partners = self.env['res.partner'].search([
    #                 '|',  # Use OR to search for both conditions
    #                 ('employee_ids.user_id', '=', user.id),  # Partners related via employee_ids
    #                 ('id', '=', user.partner_id.id),  # Partners linked via partner_id
    #                 ('active', '=', True)  # Only consider active partners for archiving
    #             ])
    #             if partners:
    #                 print(f"Found active partners related to user {user.login}: {[partner.name for partner in partners]}")
    #                 partners.write({'active': False})  # Deactivate partners
    #                 print(f"Archived {len(partners)} partner(s) related to user {user.login}")
    #             else:
    #                 print(f"No active partners found related to user {user.login}")
    #
    #         else:
    #             print(f"Activating user: {user.login} (ID: {user.id})")
    #
    #             # Unarchive the associated employee, if archived
    #             employee = self.env['hr.employee'].search([('user_id', '=', user.id), ('active', '=', False)])
    #             if employee:
    #                 print(f"Unarchiving associated employee: {employee.name}")
    #                 employee.write({'active': True})  # Reactivate employee
    #
    #             # Unarchive related partners where the user is tied through employee_ids or partner_id
    #             partners = self.env['res.partner'].search([
    #                 '|',  # Use OR to search for both conditions
    #                 ('employee_ids.user_id', '=', user.id),  # Partners related via employee_ids
    #                 ('id', '=', user.partner_id.id),  # Partners linked via partner_id
    #                 ('active', '=', False)  # Only consider archived partners for unarchiving
    #             ])
    #             if partners:
    #                 print(f"Found archived partners related to user {user.login}: {[partner.name for partner in partners]}")
    #                 partners.write({'active': True})  # Reactivate partners
    #                 print(f"Unarchived {len(partners)} partner(s) related to user {user.login}")
    #             else:
    #                 print(f"No archived partners found related to user {user.login} for unarchiving.")
