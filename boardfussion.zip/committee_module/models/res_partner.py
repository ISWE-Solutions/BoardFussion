
from odoo import models, fields, api
from odoo.exceptions import RedirectWarning
from odoo.exceptions import ValidationError, UserError

class ResPartner(models.Model):
    _inherit = 'res.partner'

    def toggle_active(self):
        super().toggle_active()  # Call the parent method

        for partner in self:
            if not partner.active:
                print(f"Archiving partner: {partner.name} (ID: {partner.id})")

                # Archive associated user, if active
                user = self.env['res.users'].search([('partner_id', '=', partner.id), ('active', '=', True)])
                if user:
                    print(f"Archiving associated user: {user.login}")
                    user.write({'active': False})  # Deactivate user

                # Archive related users through employee_ids if they are active
                related_users = self.env['res.users'].search([
                    ('employee_ids', 'in', partner.id),
                    ('active', '=', True)  # Only consider active users for archiving
                ])
                if related_users:
                    print(f"Found active users related to partner {partner.name}: {[u.login for u in related_users]}")
                    related_users.write({'active': False})  # Deactivate related users
                    print(f"Archived {len(related_users)} user(s) related to partner {partner.name}")
                else:
                    print(f"No active users found related to partner {partner.name}")

            else:
                print(f"Activating partner: {partner.name} (ID: {partner.id})")

                # Unarchive associated user, if archived
                user = self.env['res.users'].search([('partner_id', '=', partner.id), ('active', '=', False)])
                if user:
                    print(f"Unarchiving associated user: {user.login}")
                    user.write({'active': True})  # Reactivate user

                # Unarchive related users through employee_ids if they are archived
                related_users = self.env['res.users'].search([
                    ('employee_ids', 'in', partner.id),
                    ('active', '=', False)  # Only consider archived users for unarchiving
                ])
                if related_users:
                    print(f"Found archived users related to partner {partner.name}: {[u.login for u in related_users]}")
                    related_users.write({'active': True})  # Reactivate related users
                    print(f"Unarchived {len(related_users)} user(s) related to partner {partner.name}")
                else:
                    print(f"No archived users found related to partner {partner.name} for unarchiving.")

    def unlink(self):
        for partner in self:
            print(f"Attempting to delete partner: {partner.name} (ID: {partner.id})")

            # Get associated users
            users = self.env['res.users'].search([('partner_id', '=', partner.id)])
            if users:
                for user in users:
                    print(f"Found associated user: {user.login} (ID: {user.id})")

                    # Check for linked employee records
                    employees = self.env['hr.employee'].search([('user_id', '=', user.id)])
                    if employees:
                        print(f"Found associated employee(s) for user {user.login}: {[emp.name for emp in employees]}")

                        # Option 1: Unlink employees before deleting the user
                        print(f"Unlinking employees associated with user {user.login}")
                        employees.write({'user_id': False})  # Remove foreign key link to user

                        # Option 2: Archive employees (optional but not necessary)
                        # employees.write({'active': False})  # Archive employee (if needed)

                        # Now check again if employees are still linked
                        employees_check = self.env['hr.employee'].search([('user_id', '=', user.id)])
                        if employees_check:
                            print(
                                f"ERROR: Employees still linked to user {user.login}: {[emp.name for emp in employees_check]}")
                            raise ValidationError(
                                f"Cannot delete user {user.login} because employee(s) are still linked: {[emp.name for emp in employees_check]}")
                        else:
                            print(f"All employee links successfully removed for user {user.login}")

                    # Now unlink the user (only if no employees are linked)
                    print(f"Proceeding to unlink user: {user.login} (ID: {user.id})")
                    user.unlink()  # Deleting the user

            # Now, delete the partner itself
            print(f"Deleting partner: {partner.name} (ID: {partner.id})")
            super(ResPartner, self).unlink()  # Call the parent method to delete the partner

        return True


