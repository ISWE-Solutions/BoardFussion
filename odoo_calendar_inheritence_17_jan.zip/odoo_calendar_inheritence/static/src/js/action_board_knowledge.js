document.querySelectorAll('.action-btn').forEach(button => {
    button.addEventListener('click', function () {
        console.log('Button clicked');
    });
});
